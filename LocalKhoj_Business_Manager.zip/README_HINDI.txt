LocalKhoj Business Manager — मोबाइल-फ्रेंडली PWA स्टार्टर

ZIP में क्या है?
- index.html: ऐप का पेज
- style.css: मोबाइल डिज़ाइन
- app.js: ग्राहक, चेकलिस्ट, WhatsApp और CSV बैकअप
- manifest.json और sw.js: PWA/ऑफलाइन सपोर्ट की शुरुआत
- icon-192.png और icon-512.png: ऐप आइकन

मोबाइल से वेबसाइट ऑनलाइन करने के आसान स्टेप:
1. ZIP को Android फोन में Extract/Unzip करें।
2. GitHub.com खोलकर लॉगिन/अकाउंट बनाएँ।
3. नया repository बनाएँ, नाम: localkhoj-business-manager
4. Extract किए गए फोल्डर की सभी फाइलें repository में upload करें। फाइलें सीधे repository के root में हों; पूरे folder को दोबारा nested folder के रूप में न रखें।
5. Netlify.com पर लॉगिन करें और Add new site / Import an existing project से GitHub repository चुनें।
6. Build command खाली रखें और Publish directory में . (dot) डालें; फिर deploy करें।
7. Netlify द्वारा दिया गया HTTPS लिंक खोलकर वेबसाइट जाँचें।
8. Android Chrome में लिंक खोलें → ⋮ → Add to Home screen / Install app।

जरूरी सीमाएँ:
- यह starter version ग्राहक और audit data को केवल इसी फोन/ब्राउज़र के localStorage में रखता है।
- डेटा अपने-आप cloud में sync नहीं होता। Browser data साफ होने पर डेटा मिट सकता है। CSV बैकअप नियमित डाउनलोड करें।
- असली multi-user login, secure cloud database, merchant listing submission और protected Admin Panel अभी शामिल नहीं हैं; इन्हें अलग backend/auth के साथ बनाना होगा।
- ऐप आइकन PNG फाइलें placeholders हैं; अगर आइकन फाइलें मौजूद न हों तो वेबसाइट फिर भी खुलेगी, लेकिन इंस्टॉल आइकन सही दिखाने के लिए icon files जोड़ें।
- Google Business Profile की सेवाओं के लिए मालिक की अनुमति लें। पासवर्ड/OTP न लें, नकली रिव्यू न बनाएँ, और ranking की गारंटी न दें।
