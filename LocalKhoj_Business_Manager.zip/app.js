const STORE_KEY = "localkhoj-business-manager-v1";
let clients = [];
try { clients = JSON.parse(localStorage.getItem(STORE_KEY) || "[]"); } catch { clients = []; }

const $ = id => document.getElementById(id);
const money = n => "₹" + (Number(n)||0).toLocaleString("en-IN");
function save(){ localStorage.setItem(STORE_KEY, JSON.stringify(clients)); render(); }
function switchPage(page){
  document.querySelectorAll(".page").forEach(el=>el.classList.toggle("active",el.id===page));
  document.querySelectorAll(".tab").forEach(el=>el.classList.toggle("active",el.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>switchPage(btn.dataset.page)));

$("auditForm").addEventListener("submit", e=>{
  e.preventDefault();
  const checks=[...document.querySelectorAll('input[name="auditcheck"]:checked')].map(x=>x.value);
  const audit={name:$("auditName").value.trim(),area:$("auditArea").value.trim(),checks,notes:$("auditNotes").value.trim(),date:new Date().toLocaleDateString("hi-IN")};
  const noteText=`LocalKhoj Profile Audit\nदुकान: ${audit.name}\nइलाका: ${audit.area}\nचेक किए गए बिंदु: ${checks.join(", ")||"कोई नहीं"}\nनोट्स: ${audit.notes}\nतारीख: ${audit.date}`;
  const audits=JSON.parse(localStorage.getItem("localkhoj-audits-v1")||"[]"); audits.unshift(audit); localStorage.setItem("localkhoj-audits-v1",JSON.stringify(audits));
  $("auditMessage").textContent="चेकलिस्ट इस फोन के ब्राउज़र में सेव हो गई।";
  $("auditForm").reset();
});
$("mapSearch").addEventListener("click",()=>{
  const q=$("mapQuery").value.trim();
  if(!q){$("mapQuery").focus();return;}
  window.open("https://www.google.com/maps/search/"+encodeURIComponent(q),"_blank","noopener");
});
$("clientForm").addEventListener("submit",e=>{
  e.preventDefault();
  clients.unshift({id:Date.now().toString(),name:$("clientName").value.trim(),area:$("clientArea").value.trim(),phone:$("clientPhone").value.trim(),service:$("clientService").value.trim(),fee:Number($("clientFee").value)||0,status:$("clientStatus").value,paid:$("clientPaid").checked,created:new Date().toLocaleDateString("hi-IN")});
  save(); $("clientForm").reset(); $("clientFee").value="0";
  $("clientMessage").textContent="ग्राहक इस फोन के ब्राउज़र में सेव हो गया।";
});
function removeClient(id){if(confirm("क्या इस ग्राहक को हटाना चाहते हैं?")){clients=clients.filter(c=>c.id!==id);save();}}
function togglePaid(id){clients=clients.map(c=>c.id===id?{...c,paid:!c.paid}:c);save();}
function whatsapp(phone,name){
  const digits=phone.replace(/\D/g,"");
  if(!digits){alert("पहले ग्राहक का फोन नंबर जोड़ें।");return;}
  const msg=`नमस्ते ${name}, मैं LocalKhoj की ओर से आपके बिज़नेस की ऑनलाइन जानकारी/Google Business Profile की जाँच में मदद कर सकता/सकती हूँ। क्या मैं आपको मुफ्त शुरुआती चेकलिस्ट भेजूँ?`;
  window.open("https://wa.me/"+digits+"?text="+encodeURIComponent(msg),"_blank","noopener");
}
function csvEscape(v){return '"'+String(v??"").replace(/"/g,'""')+'"';}
function exportCsv(){
  const rows=[["दुकान/ग्राहक","इलाका","फोन","सर्विस","फीस","स्थिति","पेमेंट","तारीख"],...clients.map(c=>[c.name,c.area,c.phone,c.service,c.fee,c.status,c.paid?"मिल गया":"बाकी",c.created])];
  const csv="\uFEFF"+rows.map(r=>r.map(csvEscape).join(",")).join("\r\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}); const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download="LocalKhoj_Customers_Backup.csv";a.click();URL.revokeObjectURL(url);
}
$("exportCsv").addEventListener("click",exportCsv); $("exportCsv2").addEventListener("click",exportCsv);
function render(){
  const all=clients.reduce((s,c)=>s+c.fee,0), paid=clients.filter(c=>c.paid).reduce((s,c)=>s+c.fee,0);
  $("clientCount").textContent=clients.length;$("paidTotal").textContent=money(paid);$("dueTotal").textContent=money(all-paid);
  $("incomeAll").textContent=money(all);$("incomePaid").textContent=money(paid);$("incomeDue").textContent=money(all-paid);
  const list=$("clientList");
  if(!clients.length){list.innerHTML='<p class="muted">अभी कोई ग्राहक नहीं जोड़ा गया।</p>';return;}
  list.innerHTML=clients.map(c=>`<article class="client">
    <h3>${escapeHtml(c.name)} <span>${c.paid?'✅':'⏳'}</span></h3>
    <p>📍 ${escapeHtml(c.area||"इलाका नहीं दिया")} · ${escapeHtml(c.service||"सर्विस नहीं दी")}</p>
    <p>📞 ${escapeHtml(c.phone||"फोन नहीं दिया")}</p>
    <p>स्थिति: ${escapeHtml(c.status)} · फीस: <b>${money(c.fee)}</b> · पेमेंट: ${c.paid?"मिल गया":"बाकी"}</p>
    <div class="client-actions">
      <button class="small" data-wa="${c.id}">WhatsApp</button>
      <button class="small" data-paid="${c.id}">${c.paid?"पेमेंट बाकी करें":"पेमेंट मिला"}</button>
      <button class="small danger" data-del="${c.id}">हटाएँ</button>
    </div>
  </article>`).join("");
  list.querySelectorAll("[data-wa]").forEach(b=>b.onclick=()=>{const c=clients.find(x=>x.id===b.dataset.wa);whatsapp(c.phone,c.name);});
  list.querySelectorAll("[data-paid]").forEach(b=>b.onclick=()=>togglePaid(b.dataset.paid));
  list.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>removeClient(b.dataset.del));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
render();